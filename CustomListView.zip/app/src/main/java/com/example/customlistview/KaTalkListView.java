package com.example.customlistview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ListView;

public class KaTalkListView extends ListView {
    public KaTalkListView(Context context, AttributeSet attrs){
        super(context,attrs);
    }
}
