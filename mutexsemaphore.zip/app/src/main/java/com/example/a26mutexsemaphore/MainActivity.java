package com.example.a26mutexsemaphore;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.concurrent.Semaphore;

public class MainActivity extends AppCompatActivity {

    private int number = 0;
    private TextView textView;
    private Semaphore semaphore = new Semaphore(1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = (TextView)findViewById(R.id.textView);

        new Thread(){
            public void run(){
                super.run();

                try{
                    semaphore.acquire();
                    for(int i=0; i<10000000;i++) number++;
                    semaphore.release();
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView.setText(""+number);
                    }
                });
            }
        }.start();

        new Thread(){
            public void run(){
                super.run();

                try{
                    semaphore.acquire();
                    for(int i=0; i<10000000;i++) number--;
                    semaphore.release();
                }catch (InterruptedException e){
                    e.printStackTrace();
                }

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView.setText(""+number);
                    }
                });
            }
        }.start();
    }
}