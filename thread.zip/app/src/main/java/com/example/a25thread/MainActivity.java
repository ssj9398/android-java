package com.example.a25thread;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Thread thread;
    private TextView textView;
    private TextView textView1;
    private int number =0;
    private int num = 10000;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView)findViewById(R.id.textView);
        textView1 = (TextView)findViewById(R.id.textView1);

        thread = new Thread(){
            public void run(){
                super.run();

                while(true){
                    try{
                        sleep(1000);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }

                    number++;
                    Log.i("test","thread running..."+number++);

                    runOnUiThread(new Runnable(){
                        public void run(){
                            textView.setText(String.valueOf(number));
                        }
                    });
                }

            }
        };

        thread.start();

        thread = new Thread(){
            public void run(){
                super.run();

                while(true){
                    try{
                        sleep(1000);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }

                    num--;
                    Log.i("test","thread running..."+num--);

                    runOnUiThread(new Runnable(){
                        public void run(){
                            textView1.setText(String.valueOf(num));
                        }
                    });
                }

            }
        };

        thread.start();
    }
}