package com.example.a23applicationclass;

import android.app.Application;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MyApp extends Application {

    private String id = null;
    private String id1 = null;


    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("test","Application onCreate() called");
    }

    public String getId1() {
        return id1;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setId1(String id1) {
        this.id1 = id1;
    }

    public String getId() {
        return id;
    }
}
