package com.example.a23applicationclass;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class sub_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_activity);

        String id = ((MyApp)getApplication()).getId();
        String id1 = ((MyApp)getApplication()).getId1();

        ((TextView)findViewById(R.id.textView)).setText(id);
        ((TextView)findViewById(R.id.textView1)).setText(id1);
    }
}
