package com.example.a81edittext;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {


    private EditText editText;
    private EditText editText1;
    private Button button;
    private Button button1;

    @Override  //부모 메소드 재정의
    protected void onCreate(Bundle savedInstanceState) {    //화면생성 이벤트
        super.onCreate(savedInstanceState);   //부모 생성자 호출
        setContentView(R.layout.activity_main);      //메인 화면 표시
        editText = (EditText)findViewById(R.id.editText);
        button = (Button)findViewById(R.id.button);
        editText1 = (EditText)findViewById(R.id.editText1);
        button1 = (Button)findViewById(R.id.button1);

        button.setOnClickListener(new View.OnClickListener() {   //클릭리스너 생성
            @Override   //부모 메소드 재정의
            public void onClick(View v) {   //클릭 이벤트 처리
                String str = editText.getText().toString();
                editText.setText("");
                editText1.setText(str);
             }
        });

        button1.setOnClickListener(new View.OnClickListener() {   //클릭리스너 생성
            @Override   //부모 메소드 재정의
            public void onClick(View v) {   //클릭 이벤트 처리
                String str = editText1.getText().toString();
                editText1.setText("");
               editText.setText(str);
            }
        });
    }
}
